package com.narvasoft.gui;
import java.util.concurrent.atomic.AtomicInteger;
import static com.narvasoft.gui.FrmEstudiantes.jugadores;


public class Jugadores {
   public static AtomicInteger idGen = new AtomicInteger(0);
   private int id;
   private String nombre;
   private String juegoFavorito;
   private char level;
   private int maxScore;
   private int index=0;
   
   public static int ultimoId(){
    if (!jugadores.isEmpty()) {
    Jugadores lastJugadorId = jugadores.get(jugadores.size() - 1);
    int lastID = lastJugadorId.getId(); // Asume que 'getId()' devuelve el ID
    int newID=(lastID+1);
    return newID;
} else {
    return idGen.incrementAndGet();
}
    }


    public Jugadores(String nombre, String juegoFavorito, char level, int maxScore) {
        this.nombre =nombre;
        this.juegoFavorito = juegoFavorito;
        this.level = level;
        this.maxScore = maxScore;
        this.id=ultimoId();
    }
    
    public Jugadores(int id, String nombre, String juegoFavorito, char level, int maxScore){
        this.id=id;
        this.nombre =nombre;
        this.juegoFavorito = juegoFavorito;
        this.level = level;
        this.maxScore = maxScore;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getJuegoFavortio() {
        return juegoFavorito;
    }

    public void setJuegoFavortio(String juegoFavortio) {
        this.juegoFavorito = juegoFavortio;
    }

    public char getLevel() {
        return level;
    }

    public void setLevel(char level) {
        this.level = level;
    }

    public int getMaxScore() {
        return maxScore;
    }

    public void setMaxScore(int maxScore) {
        this.maxScore = maxScore;
    }
        
}
