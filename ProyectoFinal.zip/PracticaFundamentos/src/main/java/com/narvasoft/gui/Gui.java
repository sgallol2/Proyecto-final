/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.narvasoft.gui;

/**
 *
 * @author Windows
 */
public class Gui {

    
    public static void main(String[] args) {
        FrmEstudiantes frm1= new FrmEstudiantes();
        frm1.setVisible(true);
    }
}
